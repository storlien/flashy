<template>
    <Button> Flashy Knapp
    </Button>
</template>
<!-- 
<style lang="scss">
@import '../../assets/css/main.css';

.button {
    background-color: var(--primary-background);
    color: var(--primary-foreground);

    font-size: 15px;
    line-height: 1;

    padding: 5px 15px;

    border-radius: 5px;

    border: 2px solid transparent;

    transition-duration: 0.2s;
}

.button:hover {
    border: 2px solid var(--secondary);
}

</style> -->